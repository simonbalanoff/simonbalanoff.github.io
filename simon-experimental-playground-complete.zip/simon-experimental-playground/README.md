# SIMON — An Experimental Portfolio

A playful, editorial portfolio for Simon Balanoff. No 3D scene. No dependency installation. Just handcrafted HTML, CSS, modular JavaScript, interactive graphics, and little secrets.

The experience is intentionally two-layered: a clear, recruiter-friendly portfolio on the surface and an optional four-part puzzle beneath it.

## Run locally

A small local server is required because JavaScript uses ES modules. From this folder:

```bash
npm run dev
```

Visit **http://localhost:5173**. Alternative: `python3 -m http.server 5173` (requires Python instead of Node). Don't double-click `index.html` from Finder; browsers may block local JavaScript imports.

There are **no third-party runtime or build dependencies**. You can run `npm run check` to validate the source and `npm run build` to produce the deployable `dist/` folder. No `npm install` is needed.

## Deploy to simonbalanoff.github.io

This project includes `.github/workflows/deploy.yml`, a GitHub Actions workflow for *static* Pages deployment. It builds and validates the static site without installing third-party packages. The deploy artifact includes only the actual site files.

To replace an old Vite/Three.js project in the existing repository:

1. Commit or back up any changes you want to preserve.
2. Copy **all contents of this folder**, including the hidden `.github` folder, to the root of the `simonbalanoff.github.io` repository. Replace matching files.
3. You may remove old unused `package-lock.json`, `vite.config.ts`, `tsconfig*`, `public/`, and old React `.tsx` source files. Keep the NEW `package.json` in this package. They are no longer needed.
4. Commit and push to `main`.
5. In GitHub, ensure **Settings → Pages → Build and deployment → Source = GitHub Actions**.
6. Visit **https://simonbalanoff.github.io/** after the deploy workflow succeeds.

For a fully clean replacement (macOS / Linux) from inside the repo, only after backing up existing work:

```bash
rsync -av --delete --exclude='.git/' ~/Downloads/simon-experimental-playground/ ./
git add -A
git commit -m "Rebuild portfolio as interactive experimental playground"
git push origin main
```

Adjust the downloaded folder path if your browser extracts it under a different name. **Be careful:** `rsync --delete` replaces/removes old tracked site files and any uncommitted work. If you'd rather retain other repo files, copy/merge manually. The provided workflow deliberately deploys only the static site files.

## The design

- Kinetic typographic landing screen with particle field and spring-loaded drag sculpture
- Custom hover lens, magnetic navigation, responsive cards, and hover-sensitive light
- Detailed original illustrations for four engineering projects
- Animated timeline, interests constellation, and printable résumé page
- HTML/CSS physics playground with throwable, colliding skill blocks
- Mini-golf game with drag-to-aim, bounce physics, bumpers, water hazard, scoring, saved best score, and replay
- Optional four-signal exploration quest with persistent progress and a secret ending
- Command palette: **⌘K / Ctrl+K**, or `/` outside text fields
- Optional procedural sound effects (off by default)
- Keyboard-accessible buttons/dialogs, reduced-motion styles, mobile layout

The site uses the Canvas 2D API **only** for the hero particle field, mini-golf play area, and confetti. All main typography, windows, cards, and interactions are crisp HTML/CSS.

## Secret puzzle (spoilers)

The four hidden signals are awarded for: interacting with the orb; opening at least two different project files; tossing three different/any skill blocks; sinking a mini-golf putt. Click the ✦ progress pill in the navigation to view hints and open the unlocked transmission. Puzzle progress and golf record use `localStorage`.

A Konami-code surprise also exists. This is optional and not required for completion.

## Edit the portfolio content

| File | Purpose |
|---|---|
| `index.html` | Site sections, visual markup, links, and interactive elements |
| `styles.css` | Color system, typography, layouts, hover effects, responsive rules |
| `src/data.js` | Detailed project writeups, interests, and command palette options |
| `src/main.js` | UI interactions, mouse physics, command palette, and modals |
| `src/physics.js` | Interactive skill-block physics |
| `src/golf.js` | Mini-golf rendering and collision physics |
| `src/quest.js` | Puzzle discovery and persistent saves |
| `resume.html` | Printable résumé, with a browser print / Save as PDF button |
| `assets/favicon.svg` | Original site icon |
| `assets/og-card.svg` | Social sharing card |

### Please verify before publishing

The content was based on your earlier portfolio and provided background. Review your current titles, dates, project status, descriptions, and résumé before publishing. The portfolio-card illustrations contain conceptual UI and placeholder numbers, not measured production adoption data. Your personal email and LinkedIn URL weren't confirmed, so **they are not invented or linked**. Add them to the contact section once you decide what to publish. You can also add real case-study screenshots when ready.

## Technical notes

- No WebGL / Three.js, no runtime external dependencies, no font files bundled.
- Google Fonts are optional; system fallbacks are included and the page works without them.
- Internal links use relative paths, so the site works on the root GitHub Pages domain.
- Animations pause when their sections are offscreen; `prefers-reduced-motion` is respected.
- Desktop and mobile previews are included in the optional `previews/` folder.
- For further development, test by serving the folder over HTTP, rather than opening a local file directly.
