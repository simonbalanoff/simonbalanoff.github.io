import { createServer } from 'node:http'
import { readFile, stat } from 'node:fs/promises'
import { resolve, extname, sep } from 'node:path'

const root=process.cwd()
const port=Number(process.env.PORT)||5173
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.json':'application/json','.xml':'application/xml','.txt':'text/plain; charset=utf-8'}

createServer(async(req,res)=>{
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405).end();return}
  try{
    const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`)
    const decoded=decodeURIComponent(url.pathname)
    const path=resolve(root,'.'+decoded)
    if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403).end();return}
    const file=(await stat(path)).isDirectory()?resolve(path,'index.html'):path
    if(file===root||file.startsWith(root+sep)){
      const bytes=await readFile(file)
      res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-cache','Content-Length':bytes.length})
      if(req.method==='HEAD')res.end();else res.end(bytes)
      return
    }
    res.writeHead(403).end()
  }catch{res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'}).end('Not found')}
}).listen(port,()=>process.stdout.write(`SIMON / PLAYGROUND → http://localhost:${port}\n`))
