import { cpSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { execFileSync } from 'node:child_process'

const root=resolve(import.meta.dirname,'..')
execFileSync(process.execPath,[resolve(root,'scripts/check.mjs')],{stdio:'inherit'})
const dist=resolve(root,'dist')
rmSync(dist,{recursive:true,force:true})
mkdirSync(dist,{recursive:true})
for(const name of ['index.html','resume.html','styles.css','robots.txt','sitemap.xml','assets','src']){
  cpSync(resolve(root,name),resolve(dist,name),{recursive:true})
}
writeFileSync(resolve(dist,'.nojekyll'),'')
process.stdout.write('✓ Production site created in dist/\n')
