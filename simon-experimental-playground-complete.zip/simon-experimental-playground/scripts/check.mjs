import { readFileSync, existsSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { resolve } from 'node:path'
import { projects, interests } from '../src/data.js'

const root=resolve(import.meta.dirname,'..')
const get=file=>readFileSync(resolve(root,file),'utf8')
const files=['src/main.js','src/data.js','src/physics.js','src/golf.js','src/quest.js','scripts/serve.mjs','scripts/build.mjs']
for(const file of files){execFileSync(process.execPath,['--check',resolve(root,file)],{stdio:'pipe'});process.stdout.write(`✓ Syntax: ${file}\n`)}
const html=get('index.html'),resume=get('resume.html'),css=get('styles.css')
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1])
const dup=ids.filter((id,i)=>ids.indexOf(id)!==i)
if(dup.length)throw new Error(`Duplicate HTML IDs: ${dup.join(', ')}`)
for(const project of Object.keys(projects)){if(!html.includes(`data-project="${project}"`))throw new Error(`Project UI missing for ${project}`)}
for(const interest of Object.keys(interests)){if(!html.includes(`data-interest="${interest}"`))throw new Error(`Interest UI missing for ${interest}`)}
for(const file of ['assets/favicon.svg','assets/og-card.png','src/main.js','styles.css','resume.html','robots.txt','sitemap.xml']){
  if(!existsSync(resolve(root,file)))throw new Error(`Missing required file: ${file}`)
}
if(!html.includes('src="src/main.js"'))throw new Error('Entry module missing')
if(!css.includes('prefers-reduced-motion'))throw new Error('Reduced-motion support missing')
if(!resume.includes('window.print()'))throw new Error('Print résumé action missing')
process.stdout.write(`✓ ${ids.length} unique HTML IDs\n✓ ${Object.keys(projects).length} project files\n✓ ${Object.keys(interests).length} interest hotspots\n✓ Required assets, interactions and accessibility styles\nALL STATIC CHECKS PASSED\n`)
