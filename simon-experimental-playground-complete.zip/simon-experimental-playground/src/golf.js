const W=840,H=480
const START={x:107,y:376}
const HOLE={x:740,y:92,r:18}
const WALLS=[{x:248,y:100,w:35,h:220},{x:345,y:285,w:208,h:26},{x:530,y:118,w:26,h:115}]
const BUMPERS=[{x:424,y:177,r:30},{x:653,y:258,r:28}]
const WATER={x:569,y:359,w:144,h:61}

export function initGolf({ discover, celebrate, playSound, notify }) {
  const canvas=document.getElementById('golf-canvas')
  const ctx=canvas.getContext('2d')
  const win=document.getElementById('golf-win')
  const strokeEl=document.getElementById('stroke-number')
  const statusEl=document.getElementById('golf-status')
  const bestEl=document.getElementById('golf-best')
  let best=null
  try {const saved=Number(localStorage.getItem('simon-golf-best'));if(saved>0&&saved<100)best=saved}catch{}
  bestEl.textContent=best===null?'—':String(best).padStart(2,'0')
  let ball,strokes,moving,dragging,aim,pulse=0,finished=false,visible=false,aimAngle=-.44
  const reset=()=>{
    ball={x:START.x,y:START.y,vx:0,vy:0,r:10,trail:[]}
    strokes=0; moving=false;dragging=false;finished=false;aim=null
    strokeEl.textContent='00';statusEl.textContent='READY';win.hidden=true
  }
  reset()
  const scaleCanvas=()=>{
    const dpr=Math.min(window.devicePixelRatio||1,2.5)
    canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr)
    ctx.setTransform(dpr,0,0,dpr,0,0)
  }
  scaleCanvas()
  window.addEventListener('resize',scaleCanvas,{passive:true})
  const point=e=>{const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*W,y:(e.clientY-r.top)/r.height*H}}
  const limit=(value,min,max)=>Math.max(min,Math.min(max,value))
  const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)
  function stroke(dx,dy){
    const len=Math.hypot(dx,dy)
    if(len<7||moving||finished)return
    const p=Math.min(1,len/145)
    const speed=6+19*p
    ball.vx=dx/len*speed;ball.vy=dy/len*speed
    moving=true;strokes++
    strokeEl.textContent=String(strokes).padStart(2,'0')
    statusEl.textContent='IN PLAY'
    playSound?.('putt')
  }
  canvas.tabIndex=0
  canvas.addEventListener('pointerdown',e=>{
    if(finished||moving)return
    const p=point(e)
    if(dist(p,ball)>57)return
    dragging=true;aim=p
    canvas.setPointerCapture(e.pointerId)
    e.preventDefault()
  })
  canvas.addEventListener('pointermove',e=>{
    if(dragging)aim=point(e)
  })
  canvas.addEventListener('pointerup',e=>{
    if(!dragging)return
    const p=point(e)
    dragging=false;aim=null
    stroke(ball.x-p.x,ball.y-p.y)
  })
  canvas.addEventListener('pointercancel',()=>{dragging=false;aim=null})
  canvas.addEventListener('keydown',e=>{
    if(e.key.toLowerCase()==='r'){reset();e.preventDefault()}
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){aimAngle+=e.key==='ArrowLeft'?-.12:.12;e.preventDefault()}
    if(e.key==='ArrowUp'||e.key==='ArrowDown'){aimAngle+=e.key==='ArrowUp'?-.06:.06;e.preventDefault()}
    if(e.key===' '){stroke(Math.cos(aimAngle)*115,Math.sin(aimAngle)*115);e.preventDefault()}
  })
  document.getElementById('golf-reset').addEventListener('click',reset)
  document.getElementById('golf-play-again').addEventListener('click',reset)
  const victory=()=>{
    if(finished)return
    finished=true;moving=false;ball.vx=0;ball.vy=0
    statusEl.textContent='SUNK!'
    if(best===null||strokes<best){best=strokes;bestEl.textContent=String(best).padStart(2,'0');try{localStorage.setItem('simon-golf-best',String(best))}catch{}}
    document.getElementById('golf-win-copy').textContent=strokes===1?'A hole in one? Are you a wizard?':`You finished in ${strokes} stroke${strokes===1?'':'s'}. Nicely played.`
    win.hidden=false
    const first=discover(3)
    if(!first)celebrate(75)
    playSound?.('win')
  }
  function bounceRect(rect){
    const closestX=limit(ball.x,rect.x,rect.x+rect.w),closestY=limit(ball.y,rect.y,rect.y+rect.h)
    let dx=ball.x-closestX,dy=ball.y-closestY,d=Math.hypot(dx,dy)
    if(d>=ball.r)return
    if(d<.001){const options=[{d:Math.abs(ball.x-rect.x),dx:-1,dy:0},{d:Math.abs(ball.x-(rect.x+rect.w)),dx:1,dy:0},{d:Math.abs(ball.y-rect.y),dx:0,dy:-1},{d:Math.abs(ball.y-(rect.y+rect.h)),dx:0,dy:1}].sort((a,b)=>a.d-b.d);dx=options[0].dx;dy=options[0].dy;d=1}
    const nx=dx/d,ny=dy/d
    ball.x+=nx*(ball.r-d+.6);ball.y+=ny*(ball.r-d+.6)
    const dot=ball.vx*nx+ball.vy*ny
    if(dot<0){ball.vx-=(1+.79)*dot*nx;ball.vy-=(1+.79)*dot*ny;playSound?.('bounce')}
  }
  function bounceCircle(o){
    const dx=ball.x-o.x,dy=ball.y-o.y,d=Math.hypot(dx,dy),min=ball.r+o.r
    if(d>=min||d===0)return
    const nx=dx/d,ny=dy/d
    ball.x+=nx*(min-d+.6);ball.y+=ny*(min-d+.6)
    const dot=ball.vx*nx+ball.vy*ny
    if(dot<0){ball.vx-=(1+.9)*dot*nx;ball.vy-=(1+.9)*dot*ny;playSound?.('bounce')}
  }
  function tick(dt){
    if(!moving||finished)return
    const substeps=Math.max(1,Math.ceil(dt*3))
    for(let s=0;s<substeps;s++){
      const delta=dt/substeps
      ball.x+=ball.vx*delta;ball.y+=ball.vy*delta
      const friction=Math.pow(.977,delta)
      ball.vx*=friction;ball.vy*=friction
      const xMin=38+ball.r,xMax=802-ball.r,yMin=38+ball.r,yMax=442-ball.r
      if(ball.x<xMin){ball.x=xMin;ball.vx=Math.abs(ball.vx)*.85}
      if(ball.x>xMax){ball.x=xMax;ball.vx=-Math.abs(ball.vx)*.85}
      if(ball.y<yMin){ball.y=yMin;ball.vy=Math.abs(ball.vy)*.85}
      if(ball.y>yMax){ball.y=yMax;ball.vy=-Math.abs(ball.vy)*.85}
      for(const wall of WALLS)bounceRect(wall)
      for(const bumper of BUMPERS)bounceCircle(bumper)
      if(ball.x>WATER.x&&ball.x<WATER.x+WATER.w&&ball.y>WATER.y&&ball.y<WATER.y+WATER.h){
        ball.x=START.x;ball.y=START.y;ball.vx=0;ball.vy=0;moving=false;statusEl.textContent='WATER!';notify('SPLASH! BACK TO THE TEE');playSound?.('bounce');break
      }
      if(dist(ball,HOLE)<HOLE.r+2){victory();break}
    }
    ball.trail.push({x:ball.x,y:ball.y})
    if(ball.trail.length>14)ball.trail.shift()
    if(moving&&Math.hypot(ball.vx,ball.vy)<.15){ball.vx=0;ball.vy=0;moving=false;statusEl.textContent='YOUR TURN'}
  }
  function roundRect(x,y,w,h,r,fill,stroke,width=1){
    ctx.beginPath();ctx.roundRect(x,y,w,h,r)
    if(fill){ctx.fillStyle=fill;ctx.fill()}
    if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke()}
  }
  function circle(x,y,r,fill,stroke,width=1){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke()}}
  function text(s,x,y,size=11,color='#e4f9cc',weight='500',align='left'){
    ctx.fillStyle=color;ctx.textAlign=align;ctx.font=`${weight} ${size}px 'DM Mono',monospace`;ctx.fillText(s,x,y)
  }
  function draw(){
    ctx.clearRect(0,0,W,H)
    roundRect(7,8,W-14,H-16,24,'#19342d')
    ctx.save();ctx.beginPath();ctx.roundRect(22,22,W-44,H-44,17);ctx.clip()
    const grass=ctx.createLinearGradient(0,30,W,H)
    grass.addColorStop(0,'#345b45');grass.addColorStop(.5,'#447352');grass.addColorStop(1,'#2a5d49')
    ctx.fillStyle=grass;ctx.fillRect(22,22,W-44,H-44)
    ctx.save();ctx.translate(420,240);ctx.rotate(-.28)
    for(let i=-8;i<12;i++){ctx.fillStyle=i%2===0?'#ffffff07':'#050f1208';ctx.fillRect(i*91,-600,46,1200)}
    ctx.restore()
    ctx.strokeStyle='#def2ca15';ctx.lineWidth=1
    for(let x=0;x<W;x+=45){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
    for(let y=0;y<H;y+=45){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
    roundRect(22,22,W-44,H-44,18,null,'#a1c594',5)
    roundRect(30,30,W-60,H-60,15,null,'#123a3055',1)
    roundRect(82,344,74,64,18,'#cfeb9770','#ddf9b999',1)
    text('TEE',99,345,10,'#eefbd4')
    for(const wall of WALLS){
      roundRect(wall.x+5,wall.y+7,wall.w,wall.h,8,'#0a2e2988')
      roundRect(wall.x,wall.y,wall.w,wall.h,8,'#e8dcb8','#9b8d6a',2)
      roundRect(wall.x+5,wall.y+5,wall.w-10,wall.h-10,4,'#b6a58060')
    }
    for(const b of BUMPERS){
      circle(b.x+4,b.y+7,b.r+5,'#0a2a2b80')
      circle(b.x,b.y,b.r+4,'#e5f8d6')
      circle(b.x,b.y,b.r,'#ec997a','#fbe6c6',4)
      circle(b.x-7,b.y-8,b.r*.42,'#ffd2a5aa')
      circle(b.x,b.y,b.r*.55,null,'#a85e4b88',2)
    }
    roundRect(WATER.x+2,WATER.y+4,WATER.w,WATER.h,15,'#0b2e3888')
    roundRect(WATER.x,WATER.y,WATER.w,WATER.h,15,'#6bacc3','#b2e4db',3)
    ctx.save();ctx.beginPath();ctx.roundRect(WATER.x,WATER.y,WATER.w,WATER.h,15);ctx.clip()
    for(let i=0;i<5;i++){
      ctx.beginPath();ctx.strokeStyle='#f2fbf77d';ctx.lineWidth=2
      for(let x=WATER.x;x<=WATER.x+WATER.w;x+=6){const y=WATER.y+8+i*14+Math.sin(x*.065+pulse*.025+i)*3;if(x===WATER.x)ctx.moveTo(x,y);else ctx.lineTo(x,y)}
      ctx.stroke()
    }
    ctx.restore()
    circle(HOLE.x+4,HOLE.y+5,HOLE.r+14,'#e2f4a259')
    circle(HOLE.x,HOLE.y,HOLE.r+6,'#9edb86')
    circle(HOLE.x,HOLE.y,HOLE.r,'#091b19')
    circle(HOLE.x-4,HOLE.y-5,7,'#061510')
    ctx.strokeStyle='#f2f4d1';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(HOLE.x+4,HOLE.y);ctx.lineTo(HOLE.x+4,HOLE.y-69);ctx.stroke()
    ctx.fillStyle='#f6dd85';ctx.beginPath();ctx.moveTo(HOLE.x+6,HOLE.y-67);ctx.lineTo(HOLE.x+51,HOLE.y-57);ctx.lineTo(HOLE.x+6,HOLE.y-45);ctx.fill()
    text('HOLE 01',HOLE.x-10,HOLE.y+48,10,'#d7f0d1','500','center')
    for(let i=0;i<ball.trail.length;i++){
      const t=ball.trail[i],alpha=(i/ball.trail.length)*.28
      circle(t.x,t.y,2+i/ball.trail.length*2,`rgba(233,255,207,${alpha})`)
    }
    if(dragging&&aim){
      const dx=ball.x-aim.x,dy=ball.y-aim.y,len=Math.hypot(dx,dy)
      if(len>2){
        const capped=Math.min(145,len),dirX=dx/len,dirY=dy/len
        ctx.beginPath();ctx.setLineDash([8,8]);ctx.moveTo(ball.x,ball.y);ctx.lineTo(ball.x+dirX*(70+capped*.55),ball.y+dirY*(70+capped*.55));ctx.strokeStyle='#f4ffcfbb';ctx.lineWidth=2;ctx.stroke();ctx.setLineDash([])
        circle(ball.x-dirX*capped,ball.y-dirY*capped,9,'#d3fa6988','#efffd7',1)
        const barX=ball.x-55,barY=ball.y-42
        roundRect(barX,barY,110,8,5,'#09272180');roundRect(barX,barY,110*Math.min(1,len/145),8,5,'#defe81')
      }
    }
    const shadow=ctx.createRadialGradient(ball.x+3,ball.y+6,1,ball.x+3,ball.y+6,20)
    shadow.addColorStop(0,'#0b241d88');shadow.addColorStop(1,'#0b241d00')
    circle(ball.x+3,ball.y+6,20,shadow)
    const sphere=ctx.createRadialGradient(ball.x-4,ball.y-5,2,ball.x,ball.y,ball.r+1)
    sphere.addColorStop(0,'#fff');sphere.addColorStop(.4,'#f8fbf4');sphere.addColorStop(1,'#adccc0')
    circle(ball.x,ball.y,ball.r,sphere,'#ffffffab',1)
    circle(ball.x-3,ball.y-4,2.2,'#ffffff')
    if(!moving&&!dragging&&!finished){
      circle(ball.x,ball.y,ball.r+16,null,'#def48d78',1.4)
      circle(ball.x,ball.y,ball.r+19+Math.sin(pulse*.04)*2,null,'#def48d20',1)
    }
    ctx.restore()
  }
  new IntersectionObserver(entries=>visible=entries[0]?.isIntersecting??false).observe(canvas)
  let previous=performance.now()
  function frame(now){const dt=Math.min(2.4,(now-previous)/16.666);previous=now;if(visible&&!document.hidden){pulse+=dt;tick(dt);draw()}requestAnimationFrame(frame)}
  draw();requestAnimationFrame(frame)
  return{reset}
}
