const KEY = 'simon-experimental-quest-v1'
const SIGNALS = ['✳', '↗', '◉', '★']
const LABELS = ['KINETIC ENERGY', 'CURIOUS ENGINEER', 'LET IT FALL', 'THE PERFECT PUTT']

export function initQuest({ onSound, celebrate, notify }) {
  let found = new Set()
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '[]')
    if (Array.isArray(saved)) found = new Set(saved.filter(n => Number.isInteger(n) && n >= 0 && n < 4))
  } catch { found = new Set() }

  const panel = document.getElementById('quest-panel')
  const scrim = document.getElementById('quest-scrim')
  const final = document.getElementById('final-dialog')
  const trigger = document.getElementById('quest-trigger')
  const unlock = document.getElementById('quest-unlock')
  const render = () => {
    document.getElementById('quest-count').textContent = `${found.size} / 4`
    document.querySelectorAll('.quest-slot').forEach((slot, i) => {
      slot.classList.toggle('found', found.has(i))
      slot.firstChild.textContent = found.has(i) ? SIGNALS[i] : '?'
      slot.title = found.has(i) ? LABELS[i] : `Signal ${i + 1}: undiscovered`
    })
    unlock.disabled = found.size !== 4
    unlock.innerHTML = found.size === 4 ? 'OPEN FINAL TRANSMISSION <span>↗</span>' : 'TRANSMISSION LOCKED <span>↗</span>'
  }
  const open = () => {
    panel.classList.add('open')
    panel.setAttribute('aria-hidden','false')
    scrim.hidden = false
    document.getElementById('quest-close').focus()
  }
  const close = () => {
    panel.classList.remove('open')
    panel.setAttribute('aria-hidden','true')
    scrim.hidden = true
    trigger.focus()
  }
  const discover = id => {
    if (id < 0 || id > 3 || found.has(id)) return false
    found.add(id)
    try { localStorage.setItem(KEY, JSON.stringify([...found])) } catch {}
    render()
    onSound?.('discover')
    notify(`SIGNAL ${id + 1} FOUND · ${LABELS[id]}`)
    if (found.size === 4) {
      notify('ALL 4 SIGNALS FOUND · OPEN THE TRACKER')
      celebrate(80)
    }
    return true
  }
  const showFinal = () => {
    if (found.size !== 4) return
    close()
    final.showModal()
    document.body.classList.add('modal-open')
    celebrate(130)
    onSound?.('win')
  }
  trigger.addEventListener('click',open)
  document.getElementById('quest-close').addEventListener('click',close)
  scrim.addEventListener('click',close)
  document.getElementById('quest-unlock').addEventListener('click',showFinal)
  document.getElementById('quest-reset').addEventListener('click',() => {
    found.clear()
    try { localStorage.removeItem(KEY) } catch {}
    render()
    notify('THE FREQUENCIES HAVE BEEN RESET')
  })
  document.getElementById('final-close').addEventListener('click',() => final.close())
  final.addEventListener('close',() => document.body.classList.remove('modal-open'))
  document.getElementById('final-celebrate').addEventListener('click',() => { celebrate(180); onSound?.('win') })
  document.addEventListener('keydown',event => {
    if (event.key === 'Escape' && panel.classList.contains('open')) close()
  })
  render()
  return { discover, open, close, found: id => found.has(id), count: () => found.size }
}
