export const projects = {
  biddly: {
    number: '01', name: 'Biddly', status: 'IN DEVELOPMENT',
    tagline: 'The recruitment process, redesigned as software people actually want to use.',
    description: 'Biddly is a multi-tenant recruitment platform built for individual fraternity and sorority chapters. Rather than wrestling with spreadsheets, teams get configurable candidate forms, real-time assessments, event workflows, and member-specific permissions inside one carefully designed workspace.',
    highlights: ['Designed a chapter-based multi-tenant architecture', 'Built role-aware permissions, configurable forms and invitations', 'Implemented scoring, interactions, event workflows and CSV exports'],
    stack: ['Next.js', 'React', 'TypeScript', 'Fastify', 'Prisma', 'PostgreSQL']
  },
  fuel: {
    number: '02', name: 'Fuel', status: 'EXPERIMENT',
    tagline: 'Nutrition tracking that gets out of the way of living.',
    description: 'Fuel explores a friendlier iOS-first way to track calories and macros. The goal is to make daily logging fast and satisfying while experimenting with gentle accountability and a clean, distraction-free interface.',
    highlights: ['Designed a native iOS nutrition tracking experience', 'Explored behavioral accountability and simple goals', 'Prototyped daily food and macro workflows'],
    stack: ['Swift', 'iOS', 'API Design', 'Product Design']
  },
  'resident-feedback': {
    number: '03', name: 'ResidentFeedback', status: 'BUILT',
    tagline: 'A better way to hear the people who actually live there.',
    description: 'A client-facing feedback workflow linking a native mobile app to a secure API. Designed for collecting structured resident responses and turning them into information that staff can use.',
    highlights: ['Built a mobile-first resident feedback experience', 'Designed and implemented an authenticated backend API', 'Connected frontend data collection with server-side workflows'],
    stack: ['Swift', 'Node.js', 'Express', 'MongoDB', 'JWT']
  },
  'uml-visualizer': {
    number: '04', name: 'UML Visualizer', status: 'BUILT',
    tagline: 'Making code structure visible, one relationship at a time.',
    description: 'A developer tool for analyzing object-oriented code and visualizing class relationships. It turns an abstract understanding problem into a visual interface for exploring software structure.',
    highlights: ['Analyzed object-oriented source code and relationships', 'Mapped class structure into a visual representation', 'Focused on communicating complex code clearly'],
    stack: ['Java', 'Static Analysis', 'Visualization', 'OOP']
  }
}

export const interests = {
  ai: { index: '01', name: 'Mind meets machine.', description: 'Studying AI and machine learning, with a growing interest in brain-computer interfaces and intelligent prosthetics. Big problems are the point.' },
  music: { index: '02', name: 'After hours: piano.', description: 'Chopin, Rachmaninoff, Scriabin, Medtner. I love expressive music that feels like its own world, and the discipline of learning it.' },
  teaching: { index: '03', name: 'Building people up.', description: 'Leading ACM at CSU and teaching CS 214 are reminders that technology is better when people learn together.' },
  build: { index: '04', name: 'Make. Break. Repeat.', description: 'Full-stack apps, visual experiments, odd ideas, and occasional game jams. Curiosity rarely waits for a good reason.' }
}

export const paletteCommands = [
  { label: 'Selected work', hint: '01 / PROJECTS', target: '#work', icon: '↗' },
  { label: 'About Simon', hint: '02 / ABOUT', target: '#about', icon: '◎' },
  { label: 'Physics experiment', hint: '03 / PLAY', target: '#play', icon: '✳' },
  { label: 'Play mini golf', hint: '04 / GAME', target: '#golf', icon: '⛳' },
  { label: 'Other curiosities', hint: '05 / MORE', target: '#curiosity', icon: '✦' },
  { label: 'Get in touch', hint: '06 / CONTACT', target: '#contact', icon: '↗' },
  { label: 'View résumé', hint: 'RESUME / PRINTABLE PAGE', action: 'resume', icon: '▤' },
  { label: 'View GitHub', hint: 'EXTERNAL', action: 'github', icon: '⌘' },
  { label: 'Open the hidden quest', hint: 'SECRET / TRACKER', action: 'quest', icon: '✧' },
  { label: 'Shuffle the physics blocks', hint: 'ACTION / SHAKE', action: 'shake', icon: '↺' },
  { label: 'Toggle interface sound', hint: 'PREFERENCE', action: 'sound', icon: '♪' }
]
