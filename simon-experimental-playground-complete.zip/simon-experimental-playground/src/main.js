import { projects, interests, paletteCommands } from './data.js'
import { initPhysics } from './physics.js'
import { initGolf } from './golf.js'
import { initQuest } from './quest.js'

const $ = selector => document.querySelector(selector)
const $$ = selector => [...document.querySelectorAll(selector)]
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
const finePointer = window.matchMedia('(pointer:fine)').matches
let soundEnabled = false
let audio = null
let toastTimer = null

function notify(message) {
  const toast = $('#toast')
  toast.textContent = message
  toast.classList.add('visible')
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 3200)
}

function playSound(kind='tap') {
  if(!soundEnabled)return
  try {
    audio ??= new (window.AudioContext||window.webkitAudioContext)()
    if(audio.state==='suspended')audio.resume()
    const now=audio.currentTime
    const sounds={tap:[[500,.04]],toss:[[240,.09],[310,.12]],bounce:[[290,.04]],putt:[[480,.08],[350,.1]],discover:[[540,.11],[690,.11],[830,.2]],win:[[400,.13],[530,.13],[660,.13],[930,.3]]}
    const notes=sounds[kind]||sounds.tap
    let offset=0
    for(const [freq,duration] of notes){
      const osc=audio.createOscillator(),gain=audio.createGain()
      osc.type=kind==='bounce'?'triangle':'sine'
      osc.frequency.setValueAtTime(freq,now+offset)
      gain.gain.setValueAtTime(.0001,now+offset)
      gain.gain.exponentialRampToValueAtTime(kind==='win'?.085:.052,now+offset+.014)
      gain.gain.exponentialRampToValueAtTime(.0001,now+offset+duration)
      osc.connect(gain).connect(audio.destination)
      osc.start(now+offset);osc.stop(now+offset+duration+.012)
      offset+=duration*.82
    }
  } catch {}
}

function celebrate(count=80){
  if(reduceMotion)return
  const canvas=$('#confetti-canvas'),ctx=canvas.getContext('2d')
  const dpr=Math.min(devicePixelRatio||1,2)
  canvas.width=Math.floor(innerWidth*dpr);canvas.height=Math.floor(innerHeight*dpr)
  ctx.setTransform(dpr,0,0,dpr,0,0)
  const colors=['#d6fa70','#fbf4dc','#9fd8b9','#ff9e83','#aad7f4','#e6a7c9']
  const bits=Array.from({length:count},()=>({x:innerWidth*(.2+Math.random()*.6),y:innerHeight*(.28+Math.random()*.26),vx:(Math.random()-.5)*19,vy:-Math.random()*15-3,r:2+Math.random()*5,rotate:Math.random()*6,spin:(Math.random()-.5)*.24,color:colors[Math.floor(Math.random()*colors.length)]}))
  let frames=0
  function tick(){
    ctx.clearRect(0,0,innerWidth,innerHeight)
    frames++
    for(const b of bits){b.x+=b.vx;b.y+=b.vy;b.vx*=.994;b.vy+=.34;b.rotate+=b.spin;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.rotate);ctx.fillStyle=b.color;ctx.fillRect(-b.r/2,-b.r,b.r,b.r*2);ctx.restore()}
    if(frames<180)requestAnimationFrame(tick);else ctx.clearRect(0,0,innerWidth,innerHeight)
  }
  requestAnimationFrame(tick)
}

const quest=initQuest({onSound:playSound,celebrate,notify})
const physics=initPhysics({discover:quest.discover,notify,playSound})
initGolf({discover:quest.discover,notify,celebrate,playSound})

$('#sound-toggle').addEventListener('click',()=>{
  soundEnabled=!soundEnabled
  $('#sound-toggle').setAttribute('aria-pressed',String(soundEnabled))
  $('#sound-label').textContent=soundEnabled?'SOUND ON':'SOUND OFF'
  $('#sound-symbol').textContent=soundEnabled?'♫':'♪'
  playSound('tap')
})

$('#current-year').textContent=String(new Date().getFullYear())
$('#back-top').addEventListener('click',()=>window.scrollTo({top:0,behavior:reduceMotion?'auto':'smooth'}))
$('#copy-link').addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText(location.href.split('#')[0]);notify('PORTFOLIO LINK COPIED ✓');playSound('tap')}
  catch{const temp=document.createElement('textarea');temp.value=location.href.split('#')[0];temp.style.position='fixed';temp.style.opacity='0';document.body.appendChild(temp);temp.select();const okay=document.execCommand('copy');temp.remove();notify(okay?'PORTFOLIO LINK COPIED ✓':'COPY THIS URL FROM YOUR ADDRESS BAR')}
})

const revealObserver=new IntersectionObserver(entries=>{
  for(const e of entries){if(e.isIntersecting){e.target.classList.add('in-view');revealObserver.unobserve(e.target)}}
},{rootMargin:'0px 0px -7% 0px',threshold:.06})
$$('.reveal').forEach((element,index)=>{if(reduceMotion)element.classList.add('in-view');else{element.style.transitionDelay=`${Math.min(index%4,2)*75}ms`;revealObserver.observe(element)}})

const progress=()=>{$('#site-progress').style.width=`${Math.min(100,100*window.scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight))}%`}
window.addEventListener('scroll',progress,{passive:true});progress()
const menu=$('#menu-toggle')
menu.addEventListener('click',()=>{
  const opened=$('.nav-links').classList.toggle('open')
  menu.setAttribute('aria-expanded',String(opened))
  playSound('tap')
})
$$('.nav-links a').forEach(a=>a.addEventListener('click',()=>{$('.nav-links').classList.remove('open');menu.setAttribute('aria-expanded','false')}))

const cursor=$('#custom-cursor'),glow=$('#cursor-glow')
if(finePointer&&!reduceMotion){
  let targetX=-100,targetY=-100,x=-100,y=-100
  window.addEventListener('pointermove',e=>{targetX=e.clientX;targetY=e.clientY},{passive:true})
  const tick=()=>{
    x+=(targetX-x)*.2;y+=(targetY-y)*.2
    cursor.style.left=`${x}px`;cursor.style.top=`${y}px`
    glow.style.left=`${targetX}px`;glow.style.top=`${targetY}px`
    requestAnimationFrame(tick)
  }
  tick()
  $$('button,a,.project-card').forEach(el=>{
    el.addEventListener('pointerenter',()=>cursor.classList.add('visible'))
    el.addEventListener('pointerleave',()=>cursor.classList.remove('visible'))
  })
  $$('.magnetic').forEach(el=>{
    el.addEventListener('pointermove',e=>{
      const r=el.getBoundingClientRect()
      const dx=(e.clientX-r.left-r.width/2)*.12,dy=(e.clientY-r.top-r.height/2)*.12
      if(el.classList.contains('circle-cta'))return
      el.style.translate=`${dx}px ${dy}px`
    })
    el.addEventListener('pointerleave',()=>el.style.translate='0px 0px')
  })
  $$('.tilt-card').forEach(el=>{
    el.addEventListener('pointermove',e=>{
      const rect=el.getBoundingClientRect()
      const px=(e.clientX-rect.left)/rect.width,py=(e.clientY-rect.top)/rect.height
      el.style.setProperty('--rx',`${(0.5-py)*3}deg`)
      el.style.setProperty('--ry',`${(px-0.5)*-3}deg`)
      const art=el.querySelector('.project-art')
      art.style.setProperty('--px',`${px*100}%`);art.style.setProperty('--py',`${py*100}%`)
    })
    el.addEventListener('pointerleave',()=>{el.style.setProperty('--rx','0deg');el.style.setProperty('--ry','0deg')})
  })
}

function initField(){
  const canvas=$('#hero-field'),section=$('#top'),ctx=canvas.getContext('2d')
  let w=0,h=0,particles=[],pointer={x:-1000,y:-1000},active=false
  const resize=()=>{
    const dpr=Math.min(devicePixelRatio||1,2)
    w=section.clientWidth;h=section.clientHeight
    canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr)
    ctx.setTransform(dpr,0,0,dpr,0,0)
    const total=Math.min(85,Math.round(w*h/15000))
    particles=Array.from({length:total},()=>({x:Math.random()*w,y:Math.random()*h,ox:Math.random()*w,oy:Math.random()*h,vx:0,vy:0,r:.7+Math.random()*1.7}))
  }
  section.addEventListener('pointermove',e=>{const r=section.getBoundingClientRect();pointer={x:e.clientX-r.left,y:e.clientY-r.top}},{passive:true})
  section.addEventListener('pointerleave',()=>pointer={x:-1000,y:-1000})
  new IntersectionObserver(entries=>active=entries[0]?.isIntersecting??false).observe(section)
  let frame=0
  function draw(){
    if(active&&!document.hidden){
      frame++
      ctx.clearRect(0,0,w,h)
      for(const p of particles){
        const dx=p.x-pointer.x,dy=p.y-pointer.y,d=Math.hypot(dx,dy)||1
        if(d<190){const f=(1-d/190)*.65;p.vx+=dx/d*f;p.vy+=dy/d*f}
        p.vx+=(p.ox-p.x)*.003;p.vy+=(p.oy-p.y)*.003
        p.vx*=.89;p.vy*=.89;p.x+=p.vx;p.y+=p.vy
        ctx.beginPath();ctx.fillStyle=d<190?'#d8fc9088':'#a8c9b34d';ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill()
      }
      if(pointer.x>-100){
        const g=ctx.createRadialGradient(pointer.x,pointer.y,5,pointer.x,pointer.y,190)
        g.addColorStop(0,'#d1ffc20a');g.addColorStop(1,'#c5ffc000')
        ctx.fillStyle=g;ctx.fillRect(pointer.x-190,pointer.y-190,380,380)
      }
    }
    if(!reduceMotion)requestAnimationFrame(draw)
  }
  resize();window.addEventListener('resize',resize,{passive:true});draw()
}
initField()

function initHeroOrb(){
  const orb=$('#hero-orb')
  let x=0,y=0,vx=0,vy=0,desiredX=0,desiredY=0,drag=null,movement=0
  orb.addEventListener('pointerdown',e=>{
    if(e.button!==0)return
    drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y}
    movement=0;orb.setPointerCapture(e.pointerId);e.preventDefault()
  })
  orb.addEventListener('pointermove',e=>{
    if(!drag||drag.id!==e.pointerId)return
    movement=Math.max(movement,Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY))
    desiredX=Math.max(-105,Math.min(105,drag.x+e.clientX-drag.startX))
    desiredY=Math.max(-95,Math.min(95,drag.y+e.clientY-drag.startY))
  })
  const release=e=>{
    if(!drag||drag.id!==e.pointerId)return
    drag=null;desiredX=0;desiredY=0
    if(movement>35||movement<8){quest.discover(0);playSound('tap')}
  }
  orb.addEventListener('pointerup',release)
  orb.addEventListener('pointercancel',()=>{drag=null;desiredX=0;desiredY=0})
  orb.addEventListener('click',()=>{if(movement<8){quest.discover(0)}})
  if(reduceMotion)return
  const tick=()=>{
    vx+=(desiredX-x)*.047;vy+=(desiredY-y)*.047
    vx*=.85;vy*=.85;x+=vx;y+=vy
    orb.style.transform=`translate3d(${x}px,${y}px,0) rotate(${x*.075}deg)`
    requestAnimationFrame(tick)
  }
  tick()
}
initHeroOrb()

const modal=$('#project-modal')
const visitedProjects=new Set()
function openProject(id){
  const data=projects[id]
  if(!data)return
  $('#modal-counter').textContent=data.number
  $('#modal-index-label').textContent=`${data.number} — 04`
  $('#modal-status').textContent=data.status
  $('#project-modal-title').textContent=data.name
  $('#modal-tagline').textContent=data.tagline
  $('#modal-description').textContent=data.description
  $('#modal-highlights').replaceChildren(...data.highlights.map(item=>{const li=document.createElement('li');li.textContent=item;return li}))
  $('#modal-tags').replaceChildren(...data.stack.map(item=>{const span=document.createElement('span');span.textContent=item;return span}))
  if(!modal.open)modal.showModal()
  document.body.classList.add('modal-open')
  visitedProjects.add(id)
  if(visitedProjects.size>=2)quest.discover(1)
  playSound('tap')
}
$$('[data-project]').forEach(card=>card.addEventListener('click',()=>openProject(card.dataset.project)))
$('#modal-close').addEventListener('click',()=>modal.close())
modal.addEventListener('close',()=>document.body.classList.remove('modal-open'))
modal.addEventListener('click',e=>{if(e.target===modal)modal.close()})
$('#work-hidden-trigger').addEventListener('click',()=>{notify('TWO PROJECT FILES. ONE HIDDEN SIGNAL.');playSound('tap')})

$$('.interest-node').forEach(btn=>btn.addEventListener('click',()=>{
  const item=interests[btn.dataset.interest]
  $('#interest-index').textContent=item.index
  $('#interest-name').textContent=item.name
  $('#interest-description').textContent=item.description
  $('#interest-panel').classList.add('open')
  $$('.interest-node').forEach(node=>node.classList.toggle('active',node===btn))
  playSound('tap')
}))
$('#interest-close').addEventListener('click',()=>{$('#interest-panel').classList.remove('open');$$('.interest-node').forEach(node=>node.classList.remove('active'))})

const cmd=$('#command-dialog'),cmdInput=$('#command-input')
let commandList=[],selectedCommand=0
function executeCommand(item){
  if(!item)return
  cmd.close()
  if(item.target){document.querySelector(item.target)?.scrollIntoView({behavior:reduceMotion?'auto':'smooth'})}
  if(item.action==='quest')quest.open()
  if(item.action==='shake'){$('#play').scrollIntoView({behavior:reduceMotion?'auto':'smooth'});setTimeout(()=>physics.shake(),340)}
  if(item.action==='sound')$('#sound-toggle').click()
  if(item.action==='resume')window.open('resume.html','_blank','noopener,noreferrer')
  if(item.action==='github')window.open('https://github.com/simonbalanoff','_blank','noopener,noreferrer')
  playSound('tap')
}
function renderCommandList(query=''){
  commandList=paletteCommands.filter(item=>`${item.label} ${item.hint}`.toLowerCase().includes(query.toLowerCase()))
  selectedCommand=0
  const list=$('#command-results')
  list.replaceChildren(...commandList.map((item,index)=>{
    const button=document.createElement('button')
    button.type='button';button.className=`command-item${index===0?' active':''}`
    const name=document.createElement('span'),hint=document.createElement('small')
    name.textContent=`${item.icon}  ${item.label}`;hint.textContent=item.hint
    button.append(name,hint)
    button.addEventListener('click',()=>executeCommand(item))
    return button
  }))
  if(!commandList.length){const empty=document.createElement('div');empty.className='command-item';empty.textContent='No matches. Try a different command.';list.append(empty)}
}
function openCommand(){if(cmd.open)return;renderCommandList();cmd.showModal();cmdInput.value='';cmdInput.focus()}
$('#command-close').addEventListener('click',()=>cmd.close())
cmd.addEventListener('click',e=>{if(e.target===cmd)cmd.close()})
cmdInput.addEventListener('input',()=>renderCommandList(cmdInput.value))
cmdInput.addEventListener('keydown',e=>{
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){
    if(!commandList.length)return
    selectedCommand=(selectedCommand+(e.key==='ArrowDown'?1:-1)+commandList.length)%commandList.length
    $$('.command-item').forEach((el,i)=>el.classList.toggle('active',i===selectedCommand))
    e.preventDefault()
  }
  if(e.key==='Enter'){executeCommand(commandList[selectedCommand]);e.preventDefault()}
})
let shortcut=null
try{shortcut=sessionStorage.getItem('seen-shortcut-hint')}catch{}
if(!shortcut&&!reduceMotion){setTimeout(()=>{$('#shortcut-tip').classList.add('visible');setTimeout(()=>$('#shortcut-tip').classList.remove('visible'),6000);try{sessionStorage.setItem('seen-shortcut-hint','1')}catch{}},6000)}
let konami=[]
const code=['arrowup','arrowup','arrowdown','arrowdown','arrowleft','arrowright','arrowleft','arrowright','b','a']
document.addEventListener('keydown',e=>{
  if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if(cmd.open)cmd.close();else openCommand()}
  if(e.key==='/'&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&!["INPUT","TEXTAREA"].includes(document.activeElement?.tagName)&&!modal.open&&!cmd.open){e.preventDefault();openCommand()}
  konami.push(e.key.toLowerCase());if(konami.length>10)konami.shift()
  if(konami.join('|')===code.join('|')){celebrate(180);notify('KONAMI CODE ACCEPTED · EXTRA CHAOS UNLOCKED');konami=[];playSound('win')}
})

window.addEventListener('pageshow',()=>{document.body.classList.remove('modal-open')})
