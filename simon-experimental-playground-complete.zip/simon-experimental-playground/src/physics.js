const LABELS = [
  ['TypeScript', '#d8f66d'], ['React', '#b7dbef'], ['Python', '#e7e9d3'],
  ['AI / ML', '#ffc39e'], ['Next.js', '#cbd3e2'], ['Java', '#d2e4b9'],
  ['C++', '#efd39c'], ['Design', '#e9b7c5'], ['Curiosity', '#f7f2e7'],
  ['Leadership', '#c0ddcd'], ['PostgreSQL', '#c6c9f2']
]

export function initPhysics({ discover, notify, playSound }) {
  const stage = document.getElementById('physics-stage')
  const holder = document.getElementById('physics-objects')
  const status = document.getElementById('physics-status')
  const gravityButton = document.getElementById('gravity-toggle')
  let gravityOn = true
  let objects = []
  let shots = 0
  let drag = null
  let visible = false
  let last = performance.now()
  const random = (a,b) => a + Math.random() * (b-a)
  const bounds = () => ({ width: stage.clientWidth, height: stage.clientHeight })
  const animate = time => {
    const dt = Math.min((time-last)/16.6667, 2.3)
    last = time
    if (visible && !document.hidden) {
      const { width, height } = bounds()
      for (const o of objects) {
        if (!o.dragging) {
          o.vy += (gravityOn ? .42 : 0) * dt
          o.vx *= Math.pow(.994,dt)
          o.vy *= Math.pow(.996,dt)
          o.x += o.vx*dt
          o.y += o.vy*dt
          const maxX = Math.max(0,width-o.width)
          const maxY = Math.max(0,height-o.height)
          if (o.x < 0) { o.x=0; o.vx=Math.abs(o.vx)*.7 }
          if (o.x > maxX) { o.x=maxX; o.vx=-Math.abs(o.vx)*.7 }
          if (o.y < 0) { o.y=0; o.vy=Math.abs(o.vy)*.6 }
          if (o.y > maxY) { o.y=maxY; o.vy=-Math.abs(o.vy)*.46; if(Math.abs(o.vy)<.65)o.vy=0; o.vx*=.975 }
          o.angle += o.spin*dt
          o.spin *= Math.pow(.98,dt)
        }
      }
      for(let i=0;i<objects.length;i++)for(let j=i+1;j<objects.length;j++){
        const a=objects[i], b=objects[j]
        if(a.dragging||b.dragging)continue
        const acx=a.x+a.width/2,acy=a.y+a.height/2,bcx=b.x+b.width/2,bcy=b.y+b.height/2
        const dx=bcx-acx,dy=bcy-acy
        const overlapX=(a.width+b.width)*.44-Math.abs(dx)
        const overlapY=(a.height+b.height)*.46-Math.abs(dy)
        if(overlapX>0&&overlapY>0){
          if(overlapY<overlapX){const s=Math.sign(dy)||1;a.y-=overlapY*.45*s;b.y+=overlapY*.55*s;const av=a.vy;a.vy=b.vy*.24;b.vy=av*.24}
          else{const s=Math.sign(dx)||1;a.x-=overlapX*.45*s;b.x+=overlapX*.55*s;const av=a.vx;a.vx=b.vx*.45;b.vx=av*.45}
        }
      }
      for(const o of objects){o.el.style.transform=`translate3d(${o.x}px,${o.y}px,0) rotate(${o.angle}deg)`}
    }
    requestAnimationFrame(animate)
  }
  const make = () => {
    const {width,height}=bounds()
    if(width<10||height<10)return
    holder.replaceChildren()
    objects=LABELS.map(([name,color],i)=>{
      const el=document.createElement('button')
      el.type='button'
      el.className='physics-item'
      el.textContent=name
      el.style.background=color
      el.setAttribute('aria-label',`Drag ${name} skill block`)
      holder.appendChild(el)
      const w=el.offsetWidth,h=el.offsetHeight
      const col=i%4,row=Math.floor(i/4)
      const x=Math.min(width-w-15,Math.max(10,(col+.24)*width/4+random(-20,20)))
      const y=Math.max(5,Math.min(height-h-5,70+row*65+random(-17,17)))
      const o={el,x,y,width:w,height:h,vx:random(-2,2),vy:random(-3,1),angle:random(-13,13),spin:random(-.14,.14),dragging:false}
      el.addEventListener('keydown',e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault()
          o.vx=random(-11,11);o.vy=random(-14,-5);o.spin=random(-2,2)
          shots++;status.textContent=`${shots} OBJECT${shots===1?'':'S'} TOSSED`
          playSound?.('toss')
          if(shots>=3)discover(2)
        }
      })
      el.addEventListener('pointerdown',e=>{
        if(e.button!==0)return
        const rect=stage.getBoundingClientRect()
        o.dragging=true
        o.vx=0;o.vy=0
        const localX=e.clientX-rect.left, localY=e.clientY-rect.top
        drag={o,id:e.pointerId,offsetX:localX-o.x,offsetY:localY-o.y,lastX:localX,lastY:localY,lastTime:performance.now(),speedX:0,speedY:0}
        el.setPointerCapture(e.pointerId)
        el.classList.add('dragging')
        el.style.zIndex='30'
        playSound?.('tap')
        e.preventDefault()
      })
      el.addEventListener('pointermove',e=>{
        if(!drag||drag.o!==o||drag.id!==e.pointerId)return
        const rect=stage.getBoundingClientRect(),now=performance.now()
        const localX=e.clientX-rect.left,localY=e.clientY-rect.top
        const t=Math.max(8,now-drag.lastTime)
        drag.speedX=(localX-drag.lastX)/t*16.667
        drag.speedY=(localY-drag.lastY)/t*16.667
        o.x=Math.min(rect.width-o.width,Math.max(0,localX-drag.offsetX))
        o.y=Math.min(rect.height-o.height,Math.max(0,localY-drag.offsetY))
        o.angle+=drag.speedX*.25
        drag.lastX=localX;drag.lastY=localY;drag.lastTime=now
      })
      const release=e=>{
        if(!drag||drag.o!==o||drag.id!==e.pointerId)return
        o.dragging=false
        const velocity=Math.hypot(drag.speedX,drag.speedY)
        o.vx=Math.max(-22,Math.min(22,drag.speedX*.9))
        o.vy=Math.max(-22,Math.min(22,drag.speedY*.9))
        o.spin=o.vx*.035
        el.classList.remove('dragging')
        el.style.zIndex='2'
        if(velocity>1.5){shots++;status.textContent=`${shots} OBJECT${shots===1?'':'S'} TOSSED`;playSound?.('toss');if(shots>=3)discover(2)}
        drag=null
      }
      el.addEventListener('pointerup',release)
      el.addEventListener('pointercancel',release)
      el.addEventListener('lostpointercapture',e=>{if(drag?.o===o){o.dragging=false;el.classList.remove('dragging');drag=null}})
      return o
    })
  }
  document.getElementById('scatter-btn').addEventListener('click',()=>{
    for(const o of objects){o.vx=random(-12,12);o.vy=random(-14,-4);o.spin=random(-2,2)}
    playSound?.('toss')
    notify('CHAOS, BUT MAKE IT EDUCATIONAL')
  })
  document.getElementById('physics-reset').addEventListener('click',()=>{make();playSound?.('tap')})
  gravityButton.addEventListener('click',()=>{
    gravityOn=!gravityOn
    gravityButton.setAttribute('aria-pressed',String(gravityOn))
    document.getElementById('gravity-state').textContent=gravityOn?'ON':'OFF'
    playSound?.('tap')
  })
  new IntersectionObserver(entries=>{visible=entries[0]?.isIntersecting??false},{threshold:0}).observe(stage)
  let previousWidth=0
  const ro=new ResizeObserver(()=>{if(stage.clientWidth!==previousWidth){previousWidth=stage.clientWidth;make()}})
  ro.observe(stage)
  setTimeout(()=>{if(!objects.length)make()},100)
  requestAnimationFrame(animate)
  return { shake:()=>document.getElementById('scatter-btn').click(),reset:make }
}
